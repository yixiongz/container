#!/bin/bash
#

read -p "使用格式 1:start, 2: del, 3: show : " Use

case $Use in
1|start)
	docker-compose up -d ;;
2|del)
	docker rm -f tomcat1 tomcat2 ;;
3|show)
	docker ps -a ;;
*)
	echo "使用格式 1:start, 2: del, 3: show" ;;
esac

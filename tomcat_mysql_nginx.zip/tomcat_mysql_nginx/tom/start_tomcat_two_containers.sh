#!/bin/bash
#
# 定义一个基础路径
Base_page=/tmp/topv1/tom/page
# 定义容器html路径
container_html=/usr/local/webroot/html
# 定义容器日志路径
container_log=/usr/local/tomcat/logs
# 定义容器配置文件路径，便于修改
container_conf=/usr/local/tomcat/conf

# 每个容器的名称属性
container_name=${Base_page}/tomcat

# 启动两个容器
for i in {1..2};do
	docker run -dit -v ${container_name}${i}/html:$container_html -v ${container_name}${i}/log:$container_log -v ${Base_page}/conf:${container_conf}  -p 1000${i}:8081 --name tomcat${i} tomcat:v1
done

docker ps




#!/bin/bash
#
# change tomcat shutdown password, then password file save from /tmp/tomcat_passwd.txt
/bin/bash /tmp/tomcat_passwd_change.sh
/usr/sbin/sshd -D &
exec ${CATALINAE_HOME}/bin/catalina.sh run

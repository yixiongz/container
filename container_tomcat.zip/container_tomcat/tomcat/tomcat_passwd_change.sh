#!/bin/bash
#

a=`cat /dev/urandom | od -x |head -n 1 | cut -d ' ' -f 3`
b=`cat /dev/urandom | od -x |head -n 1 | cut -d ' ' -f 3`
c=`cat /dev/urandom | od -x |head -n 1 | cut -d ' ' -f 3`
d=$a$b$c
/bin/sed -i "s/shutdown\=\"SHUTDOWN\"/shutdown\="$d"/g" ${CATALINA_HOME}/conf/server.xml

echo $d >> /tmp/tomcat_passwd.txt

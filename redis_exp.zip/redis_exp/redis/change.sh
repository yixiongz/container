#!/bin/bash
#
for i in {30003..30005};do
#	sed -i '/# masterauth/amasterauth 123456' ${i}/redis.conf
#	sed -i "/# requirepass/arequirepass 123456" ${i}/redis.conf
#	sed -i "s/bind 127.0.0.1/#bind 127.0.0.1/gi" ${i}/redis.conf
#	sed -i "s/daemonize no/daemonize yes/gi" ${i}/redis.conf
#	sed -i "s/6379/${i}/gi" ${i}/redis.conf 
#	sed -i "/# slaveof <masterip>/aslaveof 192.168.9.223 30003" ${i}/redis.conf
	sed -i "s@logfile ""@logfile ${PWD}/${i}/redis_${i}.log@gi" ${i}/redis.conf
done

#!/bin/bash
#
#
for i in {30001..30002};do
#	sed -i "/# bind 127.0.0.1/abind 192.168.9.223"  ${i}/sentinel.conf
#	sed -i "s/port 26379/port ${i}/gi"  ${i}/sentinel.conf
#	sed -i "s/sentinel monitor mymaster 127.0.0.1 6379 2/sentinel monitor mymaster 192.168.9.223 30003 2/gi" ${i}/sentinel.conf
#	sed -i "/# sentinel auth-pass/asentinel auth-pass mymaster 123456" ${i}/sentinel.conf
#	sed -i "s/sentinel failover-timeout mymaster 180000/sentinel failover-timeout mymaster 30000/gi" ${i}/sentinel.conf

	sed -i "10alogfile ${PWD}/${i}/sentinel_${i}.log" ${i}/sentinel.conf
done

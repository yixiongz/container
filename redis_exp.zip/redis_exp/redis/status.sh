#!/bin/bash
#
# 定义redis-server的服务路径
Path=/tmp/topv1/redis/redis-4.0.9/src

# 这里是服务
Sbin=${Path}/redis-server
Senbin=${Path}/redis-sentinel
Down=${Path}/redis-cli

server(){
	for i in {30003..30005};do
	    $Sbin ${i}/redis.conf
	done
}
sentinel(){
	for i in {30001..30002};do
	    $Senbin ${i}/sentinel.conf
	done
}

shutdowns(){
	for i in {30001..30005};do
		${Down} -h 192.168.9.223 -p ${i} -a 123456 shutdown
	done
}

read -p "输入 1: start | 2: stop | 3: show: " enabled
case $enabled in
1|start)
	server
	sentinel ;;
2|stop)
	shutdowns ;;
3|show)
	ps -ef | grep redis ;;
*)
	echo "script 1: start | 2: stop | 3: show" ;;
esac
